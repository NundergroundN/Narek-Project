let slideIndex = 0;
carousel();

function carousel() {
    let i;
    let j = document.getElementsByClassName("mySlide");
    for (i = 0; i < j.length; i++) {
      j[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > j.length) {slideIndex = 1}
    j[slideIndex-1].style.display = "block";
    setTimeout(carousel, 5000);
}

function showProductindex(category) {
  let productList = JSON.parse(localStorage.getItem('productList'))
  productList = category ? productList.filter(e => e.productCategory == category) : productList 
  container.innerHTML = ''
  
  if(productList){
    productList.forEach(product => {
      let discountt = ((product.price -(product.price * product.discount) / 100))
      container.innerHTML += `
  <div id="cont">
  <div id="cont-img"><img style = "width: 345.5px; height: 300px;" src="./img/${product.image}"></div>
  <div id="cont-p-name">
  <p>${product.id}</p>
  <p>${product.name}</p>
  </div>
  <div id="cont-p">
      <p>${product.price +'$'}</p>
      <p>${discountt +'$'}</p>
  </div>
  <div id="cont-but">
  <button id="Add" onclick="addToCart(${product.id})">Add</button>
  <button id="See" onclick="viewMoreInfo(${product.id})">See More</button>
  </div>
</div>
  `
      });
  }
}
showProductindex()

function viewMoreInfo(id){
  viewBox.classList.add('viewBoxShow')
  bg.classList.add('bgShow')

  let productList = JSON.parse(localStorage.getItem('productList'))
  let product = productList.find(e => e.id == id)

  viewBox.innerHTML = `
  <div class="boddy">
  <div id="contInf">
  <i class="fa fa-times" onclick="hideViewBox()"></i>
  <p>${product.id}</p>
  <div id="cont-description">
      <p>${product.description}</p>
  </div>
</div>
</div>
  `
}

function hideViewBox(){
  viewBox.classList.remove('viewBoxShow')
  bg.classList.remove('bgShow')
}

/* *****cart***** */

let productList = JSON.parse(localStorage.getItem('productList'))
let products = JSON.parse(localStorage.getItem('products'))

function cartShow(){
    cartBox.classList.toggle('cartShow')
}

function addToCart(id){
// let products = JSON.parse(localStorage.getItem('products'))
    let product = productList.find(e => e.id == id)
    let discountt = ((product.price -(product.price * product.discount) / 100))
    product.cartItems = product.cartItems ? ++product.cartItems : 1
    product.cartPrice = discountt * product.cartItems
    localStorage.setItem('products', JSON.stringify(productList))
    // localStorage.getItem('products', JSON.stringify(products))

    updateCart()
    hideViewBox()
}

function updateCart(){

    // let productt = {cartItems:[]}
    // let stored = localStorage.getItem('products')
    // if(stored){
    //   productt = JSON.parse(stored)
    // }
    let products = productList.filter(e => e.cartItems)
    cartItems.innerHTML = ''
    cartCountBox.innerText = products.length
    let total = 0

    if(productList.length > 0){

        products.forEach(product => {
            let discountt = ((product.price -(product.price * product.discount) / 100))
            total += product.cartPrice

            cartItems.innerHTML += `
                <div class='cartItem'>
                    <img src='./img/${product.image}'>
                    <h3>${product.name} / ${discountt} $</h3>
                    <i onclick='remove(${product.id})' id='delIcon' class='fa fa-times'></i>
                    <div class='button-group'>
                        <i class='fa fa-minus' onclick='changeCount(${product.id}, "minus")'></i>
                        <span>${product.cartItems}</span>
                        <i class='fa fa-plus' onclick='changeCount(${product.id}, )'></i>
                    </div>
                </div>
                `
              })
            }else{
              cartBox.classList.remove('cartShow')
            }
          

    totalBox.innerText = `Total: ${total} $`
  }

function remove(id){
    let product = productList.find(e => e.id == id)
    delete product.cartItems
    localStorage.setItem('products', JSON.stringify(productList))
    updateCart()
}

function changeCount(id, value){
    let product = productList.find(e => e.id == id)
    let discountt = ((product.price -(product.price * product.discount) / 100))
    value ? --product.cartItems : ++product.cartItems
    product.cartPrice = discountt * product.cartItems
    localStorage.setItem('products', JSON.stringify(productList))

    updateCart()
}

updateCart()