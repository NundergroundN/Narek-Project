let id = location.hash.slice(1)
console.log(id);
let categoryList = JSON.parse(localStorage.getItem('categoryList'))
let category = categoryList.find(element => element.id == id)

mirror2.value = `${category.name}`

function editCategoryy(){
    category.name = mirror2.value

    localStorage.setItem('categoryList',JSON.stringify(categoryList))
    location.href = 'admin.html'
}