function AddProduct(){
    location.href = 'addProduct.html'
}
function AddCategory(){
    location.href = 'addCategory.html'
}

let productList = JSON.parse(localStorage.getItem('productList'))

function showProduct() {
    let productList = JSON.parse(localStorage.getItem('productList'))
    tbbody1.innerHTML = ''

    if(productList){
        productList.forEach(product => {
            let discountt = product.price = ((product.price -(product.price * product.discount) / 100))
    tbbody1.innerHTML += `
    <tr>
    <td>${product.id}</td>
    <td>${product.name}</td>
    <td>${discountt +'$'}</td>
    <td>${product.category}</td>
    <td>${product.discount}</td>
    <td>${product.description}</td>
    <td class = "imagi"><img style = "width: 200px; height: 150px;" src="./img/${product.image}"></td>
    <td>
        <div class="action">
            <a class="edit" href="editProduct.html#${product.id}">
                <i class="fa-solid fa-pen-to-square fa-penn"></i>
            </a>
            <a class="remove" onclick="remove(${product.id})">
                <i class="fa-solid fa-trash fa-trashh"></i>
            </a>
        </div>
    </td>
</tr>
    `
        });
    }
}

function showCategory(){
    let categoryList = JSON.parse(localStorage.getItem('categoryList'))
    tbbody2.innerHTML = ''

if(categoryList){
    categoryList.forEach(category => {
        tbbody2.innerHTML += `
        <tr>
        <td>${category.id}</td>
        <td>${category.name}</td>
        <td>
            <div class="actionn">
                <a class="edit" onclick="editCategory" href="editCategory.html#${category.id}">
                    <i class="fa-solid fa-pen-to-square fa-penn2"></i>
                </a>
                <a class="remove" onclick="removeCategory(${category.id})">
                    <i class="fa-solid fa-trash fa-trashh2"></i>
                </a>
            </div>
        </td>
    </tr>
        `
    });
}
}



function remove(id){
    let productList = JSON.parse(localStorage.getItem('productList'))
    let i = productList.findIndex(e => e.id === id)
    productList.splice(i, 1)
    localStorage.setItem('productList', JSON.stringify(productList))
    showProduct()
}


function removeCategory(id){
    let categoryList = JSON.parse(localStorage.getItem('categoryList'))
    let i = categoryList.findIndex(e => e.id === id)
    categoryList.splice(i, 1)
    localStorage.setItem('categoryList', JSON.stringify(categoryList))
    showCategory()
}

function logOut(){
    localStorage.removeItem('admin')
    location.href = 'login.html'
}

showCategory()
showProduct()
