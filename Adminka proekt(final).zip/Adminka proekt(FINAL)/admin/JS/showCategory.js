function showCategory() {
    let categoryList = JSON.parse(localStorage.getItem('categoryList'));
    tbbody2.innerHTML = '';

    if (categoryList) {
        categoryList.foreach(category => {
            tbbody2.innerHTML += `
        <tr>
        <td>${category.id}</td>
        <td>${category.name}</td>
        <td>
            <div class="action">
                <a class="edit" href="editCategory.html#${category.id}">
                    <i class="fa-solid fa-pen-to-square"></i>
                </a>
                <a class="remove" onclick="removeCategory(${category.id})">
                    <i class="fa-solid fa-trash"></i>
                </a>
            </div>
        </td>
    </tr>
        `;
        });
    }
}
