function addCategoryy(){
    let id = 1
    let categoryList
    if(localStorage.getItem('categoryList')){
        categoryList = JSON.parse(localStorage.getItem('categoryList'))
    }
    else{
        categoryList = []
    }
    if(localStorage.getItem('id')){
        id = +localStorage.getItem('id') + 1
    }
    let category = {
        id: id,
        name: mirror2.value
    }
    categoryList.push(category)
    localStorage.setItem('categoryList', JSON.stringify(categoryList))
    localStorage.setItem('id',id)
    location.href = 'admin.html'
}