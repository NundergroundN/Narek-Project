function logIn(){
    if(inp1.value == "narekk" && inp2.value == "784591623"){
        location.href = 'admin.html'
    }else{
        alert('Something Wrong')
    }
}
