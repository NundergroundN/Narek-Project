let categoryList=JSON.parse(localStorage.getItem('categoryList'))
categoryList.forEach(category => {
    mirror.innerHTML += `<option>${category.name}</option>`
});
function addProductt(){
    let id = 1
    let productList
    if(localStorage.getItem('productList')){
        productList = JSON.parse(localStorage.getItem('productList'))
    }
    else{
        productList = []
    }

    if(localStorage.getItem('id')){
        id = +localStorage.getItem('id') + 1
    }
    let product = {
        id: id,
        name: Productname.value,
        price: price.value,
        category: mirror.value,
        discount: discount.value,
        description: description.value,
        image: image.files[0]['name']
    }
    productList.push(product)
    localStorage.setItem('productList', JSON.stringify(productList))
    localStorage.setItem('id',id)
    location.href = 'admin.html'
}