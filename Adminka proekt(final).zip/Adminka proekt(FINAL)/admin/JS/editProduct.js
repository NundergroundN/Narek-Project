let id = location.hash.slice(1)
// console.log(id);
let productList = JSON.parse(localStorage.getItem('productList'))
let product = productList.find(element => element.id == id)

Productname.value = `${product.name}`
price.value = `${product.price}`
discount.value = `${product.discount}`
description.value = `${product.description}`
let discountt = ((product.price -(product.price * product.discount) / 100))

function editProductt(){
    product.name = Productname.value
    product.price = discountt
    product.discount = discount.value
    product.description = description.value

    // if(image.files.length > 0){
    //     product.image = image.files(0)('name')
    // }
    localStorage.setItem('productList',JSON.stringify(productList))
    location.href = 'admin.html'
}