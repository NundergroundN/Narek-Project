import {createSlice} from "@reduxjs/toolkit";
import {fetchPosts} from "./postsAPI";

const postsSlice = createSlice({
    name:'posts',
    initialState:{
        postsData:[],
        isLoading:false,
    },
    reducers:{
        addComments(state,{payload}){
            state.postsData = state.postsData.map(post => payload.postId ===  post.id ?
                {...post,comments:[...post.comments,{
                    id:new Date().getTime().toString(),
                        body:payload.body,
                        username:payload.username
                    }]}: post)
        }
    },
    extraReducers:{
        [fetchPosts.pending]:(state)=>{
            state.isLoading = true
        },
        [fetchPosts.fulfilled]:(state,{payload})=>{
            state.postsData = [...payload]
            state.isLoading = false
        }
    },
})

export const selectPosts = state => state.posts;

export const {addComments} = postsSlice.actions;

export const postsReducer = postsSlice.reducer;