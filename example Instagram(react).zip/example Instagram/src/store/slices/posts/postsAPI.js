import {sendRequest} from "../../../helpers/sendRequest";
import {createAsyncThunk} from "@reduxjs/toolkit";

const {sendRequestGet} = sendRequest()
export const fetchPosts = createAsyncThunk(
    'posts/fetchPosts',
    async function(){
        const postsData = await sendRequestGet('https://jsonplaceholder.typicode.com/photos?_limit=100')
        const commentsData = await sendRequestGet('https://jsonplaceholder.typicode.com/comments')

        //     {
        //         id: '1',
        //         img: IMAGES.cover1,
        //         name: 'user1',
        //         likesCount: '1,200',
        //         postText: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur tenetur veritatis placeat, molestiae impedit aut provident eum quo natus molestias?',
        //         timeAgo: '2 Minutes Ago'

        const data = [
            ...postsData.map(post => ({
                id:post.id,
                img:post.url,
                name:post.title.split(' ')[0],
                likeCount:Math.round(Math.random() * 300 + 200),
                postText:post.title,
                timeAgo: Math.round(Math.random() * 5 + 3) + ' Minutes Ago',
                comments:[
                    ...commentsData.filter(comment => post.id === comment.postId)
                        .map(comItem =>({
                            postId:comItem.postId,
                            id:comItem.id,
                            username:comItem.name.split(' ')[0],
                            body:comItem.body
                        }) )
                ]
            }))
        ]

        console.log(data)

        return data
    }
)