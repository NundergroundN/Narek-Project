import './Loading.css'

export const Loading = () => {
    return(
        <div className="loadingio-spinner-spinner-87cx2awac4p">
            <div className="ldio-d7cyg580qxj">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    )
}