import React, {useEffect} from 'react'
import IMAGES from '../../images'
import Post from '../Post/Post'
import {useDispatch, useSelector} from "react-redux";
import {fetchPosts} from "../../store/slices/posts/postsAPI";
import {selectPosts} from "../../store/slices/posts/postsSlice";
import {Loading} from "../Loading/Loading";

function Posts() {
   const dispatch = useDispatch()
   const {postsData,isLoading} = useSelector(selectPosts)

  useEffect(()=>{
    dispatch(fetchPosts())
  },[])

  return (
    <>
        {
            isLoading ?
                <Loading/>
                :  postsData.map(el => <Post key={el.id} id={el.id} img={el.img} name={el.name} likesCount={el.likesCount} postText={el.postText} timeAgo={el.timeAgo} comments={el.comments} />)
        }
    </>
  )
}

export default Posts