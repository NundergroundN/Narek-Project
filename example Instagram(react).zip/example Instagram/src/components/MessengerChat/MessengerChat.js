import './MessengerChat.css'

function MessengerChat() {
  return (
	 <div className='MessengerChat'>
		
	 </div>
  )
}

export default MessengerChat
