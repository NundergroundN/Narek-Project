import React, {useRef, useState} from 'react'
import { NavLink } from 'react-router-dom'
import IMAGES from '../../images'
import {useDispatch} from "react-redux";
import {addComments} from "../../store/slices/posts/postsSlice";

function Post({id, img, name, likesCount, postText, timeAgo,comments}) {

    const [isShow,setIsShow] = useState(false)
    const formRef = useRef(null)
    const dispatch = useDispatch()

    const isShowComments = () => {
        setIsShow(!isShow)
    }

    const handlerSubmit = (e) => {
        e.preventDefault()

        dispatch(addComments({
            postId:id,
            username:'test-user',
            body:formRef.current[0].value
        }))

    }

  return (
    <div className="post">
        <div className="info">
            <NavLink style={{textDecoration: 'none'}} to={`${id}/uniq`} className="user">
                <div className="profile-pic"><img src={img} alt="" /></div>
                <p className="username">{name}</p>
            </NavLink>
            <img src={IMAGES.option} className="options" alt=""/>
        </div>
        <img src={img} className="post-image" alt=""/>
        <div className="post-content">
            <div className="reaction-wrapper">
                <img src={IMAGES.like} className="icon" alt=""/>
                <img src={IMAGES.comment} className="icon" alt=""/>
                <img src={IMAGES.send} className="icon" alt=""/>
                <img src={IMAGES.save} className="save icon" alt=""/>
            </div>
            <p className="likes">{likesCount}</p>
            <p className="description"><span>{name} </span> {postText}</p>
            <p className="post-time">{timeAgo}</p>
        </div>
            {isShow ?
               <div>
                   {comments.map(comm => <p key={comm.id} className="description"><span>{comm.username} </span> {comm.body}</p>)}
                   <h1 onClick={isShowComments}>Close Comments</h1>
               </div>:
                <h1 onClick={isShowComments}>Open Comments</h1>
            }
        <form className="comment-wrapper" ref={formRef} onSubmit={handlerSubmit}>
            <img src={IMAGES.smile} className="icon" alt=""/>
            <input type="text" className="comment-box" placeholder="Add a comment"/>
            <button className="comment-btn">post</button>
        </form>

    </div>
  )
}

export default Post