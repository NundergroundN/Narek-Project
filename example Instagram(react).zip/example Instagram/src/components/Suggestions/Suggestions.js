import React from 'react'
import { useSelector } from 'react-redux'
import Suggestion from '../Suggestion/Suggestion'

function Suggestions() {
    const suggestions = useSelector(state => state.users)
  return (
    <>
    {
        suggestions.map(el => <Suggestion key={el.id} id={el.id} name={el.name} avatar={el.avatar} />)
    }
    </>
  )
}

export default Suggestions