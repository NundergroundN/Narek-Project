import React from 'react'
import { NavLink } from 'react-router-dom'
import IMAGES from '../../images'
import Posts from '../Posts/Posts'
import Stories from '../Stories/Stories'
import Suggestions from '../Suggestions/Suggestions'

function Main() {
  return (
    <section className="main">
        <div className="wrapper">
            <div className="left-col">
                <Stories/>
                <Posts />
            </div>
            <div className="right-col">
                <NavLink to='/profile' className="profile-card">
                    <div className="profile-pic">
                        <img src={IMAGES.profile_pic} alt=""/>
                    </div>
                    <div>
                        <p className="username">modern_web_channel</p>
                        <p className="sub-text">kunaal kumar</p>
                    </div>
                    <button className="action-btn">switch</button>
                </NavLink>
                <p className="suggestion-text">Suggestions for you</p>
            </div>
        </div>
    </section>
  )
}

export default Main