export const sendRequest = () => {

    const sendRequestGet = async (url) => {
        const result = await fetch(url)
        return result.json()
    }

    return {sendRequestGet}
}